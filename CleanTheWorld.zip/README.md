Description the features

Auto incrementing of waste at the click
Establishment of a shop with mathematical calculation to subtract the number of pieces to purchase
Incrementation of energies
Conversion of waste into pieces
Conversion of energies into parts
List of items purchased in inventory
Setting up the local storage to keep the score at the refresh of the page
Filling of the gauge with the percentage of purity according to the number of clicks and the energies harvested
Passage from one level to another with change of planet
Purification level gauge
Small informative messages that appear at x garbage collected.
Json for the objects to buy, to generate the planets in the middle of the page.

The ressources we used
Github


Principle of the game

The goal is to clean up the planets.
Just click on the planet to clean it up.
Subsequently you unblock objects to improve the collection of waste.
Simply click on the buy button to place it directly in your inventory.
You can redeem the same tool several times, it automatically adds to the rest of your inventory.
Once the purity gauge is reached, you go to the next level, while keeping what you bought.